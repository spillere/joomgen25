<?php
/**
 * Dados HTML Default Template
 *
 * PHP versions 5
 *
 * @category  Template
 * @package   Basico
 * @author    Rodrigo Spillere - JetWorks <rodrigo@jetworks.com.br>
 * @copyright 2010 JetWorks. All rights reserved.
 * @license   GNU General Public License
 * @link      http://jetworks.com.br
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');
JHTML::_('behavior.formvalidation');
JHTML::_('behavior.keepalive');

?>

<h1><?php echo JText::_('Add Dados'); ?></h1>
<form id="new_dados" name="new_dados" method="post" onsubmit="return document.formvalidator.isValid(this)">
<table border="0" cellspacing="1" cellpadding="1">
            <tr>
                <td width="100" align="right" class="key"><label for="nome"> <?php echo JText::_('Nome'); ?>:</label></td>
                <td><input class="text_area" type="text" name="nome" id="nome" size="32" maxlength="250" value="<?php echo $this->item->nome;?>" /></td>
            </tr>
            <tr>
                <td width="100" align="right" class="key"><label for="cep"> <?php echo JText::_('Cep'); ?>:</label></td>
                <td><input class="text_area" type="text" name="cep" id="cep" size="32" maxlength="250" value="<?php echo $this->item->cep;?>" /></td>
            </tr>
            <tr>
                <td width="100" align="right" class="key"><label for="endereco"> <?php echo JText::_('Endereco'); ?>:</label></td>
                <td><input class="text_area" type="text" name="endereco" id="endereco" size="32" maxlength="250" value="<?php echo $this->item->endereco;?>" /></td>
            </tr>
            <tr>
                <td width="100" align="right" class="key"><label for="cidade"> <?php echo JText::_('Cidade'); ?>:</label></td>
                <td><input class="text_area" type="text" name="cidade" id="cidade" size="32" maxlength="250" value="<?php echo $this->item->cidade;?>" /></td>
            </tr>
            <tr>
                <td width="100" align="right" class="key"><label for="uf"> <?php echo JText::_('Uf'); ?>:</label></td>
                <td><input class="text_area" type="text" name="uf" id="uf" size="32" maxlength="250" value="<?php echo $this->item->uf;?>" /></td>
            </tr>
            <tr>
                <td width="100" align="right" class="key"><label for="complemento"> <?php echo JText::_('Complemento'); ?>:</label></td>
                <td><input class="text_area" type="text" name="complemento" id="complemento" size="32" maxlength="250" value="<?php echo $this->item->complemento;?>" /></td>
            </tr>
            <tr>
                <td width="100" align="right" class="key"><label for="cnpj"> <?php echo JText::_('Cnpj'); ?>:</label></td>
                <td><input class="text_area" type="text" name="cnpj" id="cnpj" size="32" maxlength="250" value="<?php echo $this->item->cnpj;?>" /></td>
            </tr>
            <tr>
                <td width="100" align="right" class="key"><label for="email"> <?php echo JText::_('Email'); ?>:</label></td>
                <td><input class="text_area" type="text" name="email" id="email" size="32" maxlength="250" value="<?php echo $this->item->email;?>" /></td>
            </tr>
            <tr>
                <td width="100" align="right" class="key"><label for="email_cobranca"> <?php echo JText::_('Email Cobranca'); ?>:</label></td>
                <td><input class="text_area" type="text" name="email_cobranca" id="email_cobranca" size="32" maxlength="250" value="<?php echo $this->item->email_cobranca;?>" /></td>
            </tr>
            <tr>
                <td width="100" align="right" class="key"><label for="dominio"> <?php echo JText::_('Dominio'); ?>:</label></td>
                <td><input class="text_area" type="text" name="dominio" id="dominio" size="32" maxlength="250" value="<?php echo $this->item->dominio;?>" /></td>
            </tr>
            <tr>
                <td width="100" align="right" class="key"><label for="nome_do_site"> <?php echo JText::_('Nome Do Site'); ?>:</label></td>
                <td><input class="text_area" type="text" name="nome_do_site" id="nome_do_site" size="32" maxlength="250" value="<?php echo $this->item->nome_do_site;?>" /></td>
            </tr>
            <tr>
                <td width="100" align="right" class="key"><label for="logo"> <?php echo JText::_('Logo'); ?>:</label></td>
                <td><input class="text_area" type="text" name="logo" id="logo" size="32" maxlength="250" value="<?php echo $this->item->logo;?>" /></td>
            </tr>

</table>
    <?php echo JHTML::_('form.token'); ?>
    <input type="submit" value="<?php echo JText::_('Submit'); ?>" />
    <input type="hidden" name="option" value="com_ps_basico" />
    <input type="hidden" name="task" value="save" />
    <input type="hidden" name="view" value="dados" />
    <input type="hidden" name="controller" value="dados" />
</form>