<?php
/**
 * HTML Default Template
 *
 * PHP versions 5
 *
 * @category  Template
 * @package   Basico
 * @author    Rodrigo Spillere - JetWorks <rodrigo@jetworks.com.br>
 * @copyright 2010 JetWorks. All rights reserved.
 * @license   GNU General Public License
 * @link      http://jetworks.com.br
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');
?>
<ul><li><a href="<?php echo JRoute::_('index.php?option=com_ps_basico&view=dados&layout=new', false); ?>">Dados New</a></li></ul>