CREATE TABLE IF NOT EXISTS `#__ps_basico_dados` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(255) NOT NULL,
  `cep` VARCHAR(255) NOT NULL,
  `endereco` VARCHAR(255) NOT NULL,
  `cidade` VARCHAR(255) NOT NULL,
  `uf` VARCHAR(255) NOT NULL,
  `complemento` VARCHAR(255) NOT NULL,
  `cnpj` VARCHAR(255) NOT NULL,
  `telefones` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) NOT NULL,
  `email_cobranca` VARCHAR(255) NOT NULL,
  `dominio` VARCHAR(255) NOT NULL,
  `nome_do_site` VARCHAR(255) NOT NULL,
  `logo` VARCHAR(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__ps_basico_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(255) NOT NULL,
  `imagem` VARCHAR(255) NOT NULL,
  `preco` VARCHAR(255) NOT NULL,
  `demo` VARCHAR(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__ps_basico_adwords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plano` VARCHAR(255) NOT NULL,
  `onde_anunciar` VARCHAR(255) NOT NULL,
  `palavras_chaves` VARCHAR(255) NOT NULL,
  `dados_google` VARCHAR(255) NOT NULL,
  `produtos_servicos` VARCHAR(255) NOT NULL,
  `vantagens` VARCHAR(255) NOT NULL,
  `obs_google` VARCHAR(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

