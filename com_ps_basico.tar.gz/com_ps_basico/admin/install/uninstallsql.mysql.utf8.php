DROP TABLE IF EXISTS `#__ps_basico_dados`;
DROP TABLE IF EXISTS `#__ps_basico_templates`;
DROP TABLE IF EXISTS `#__ps_basico_adwords`;
