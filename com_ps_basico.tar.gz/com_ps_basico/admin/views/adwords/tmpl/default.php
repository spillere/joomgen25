<?php
/**
 * Adwords HTML Default Template
 *
 * PHP versions 5
 *
 * @category  Template
 * @package   Basico
 * @author    Rodrigo Spillere - JetWorks <rodrigo@jetworks.com.br>
 * @copyright 2010 JetWorks. All rights reserved.
 * @license   GNU General Public License
 * @link      http://jetworks.com.br
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

?>

<form action="index.php" method="post" name="adminForm" id="adminForm">
    <div class="col100">
        <fieldset class="adminform"><legend><?php echo JText::_(''); ?></legend>
        <table class="admintable">
            <tr>
                <td width="100" align="right" class="key"><label for="plano"> <?php echo JText::_('Plano'); ?>:</label></td>
                <td><input class="text_area" type="text" name="plano" id="plano" size="32" maxlength="250" value="<?php echo $this->item->plano;?>" /></td>
            </tr>
            <tr>
                <td width="100" align="right" class="key"><label for="onde_anunciar"> <?php echo JText::_('Onde Anunciar'); ?>:</label></td>
                <td><input class="text_area" type="text" name="onde_anunciar" id="onde_anunciar" size="32" maxlength="250" value="<?php echo $this->item->onde_anunciar;?>" /></td>
            </tr>
            <tr>
                <td width="100" align="right" class="key"><label for="palavras_chaves"> <?php echo JText::_('Palavras Chaves'); ?>:</label></td>
                <td><input class="text_area" type="text" name="palavras_chaves" id="palavras_chaves" size="32" maxlength="250" value="<?php echo $this->item->palavras_chaves;?>" /></td>
            </tr>
            <tr>
                <td width="100" align="right" class="key"><label for="dados_google"> <?php echo JText::_('Dados Google'); ?>:</label></td>
                <td><input class="text_area" type="text" name="dados_google" id="dados_google" size="32" maxlength="250" value="<?php echo $this->item->dados_google;?>" /></td>
            </tr>
            <tr>
                <td width="100" align="right" class="key"><label for="produtos_servicos"> <?php echo JText::_('Produtos Servicos'); ?>:</label></td>
                <td><input class="text_area" type="text" name="produtos_servicos" id="produtos_servicos" size="32" maxlength="250" value="<?php echo $this->item->produtos_servicos;?>" /></td>
            </tr>
            <tr>
                <td width="100" align="right" class="key"><label for="vantagens"> <?php echo JText::_('Vantagens'); ?>:</label></td>
                <td><input class="text_area" type="text" name="vantagens" id="vantagens" size="32" maxlength="250" value="<?php echo $this->item->vantagens;?>" /></td>
            </tr>
            <tr>
                <td width="100" align="right" class="key"><label for="obs_google"> <?php echo JText::_('Obs Google'); ?>:</label></td>
                <td><input class="text_area" type="text" name="obs_google" id="obs_google" size="32" maxlength="250" value="<?php echo $this->item->obs_google;?>" /></td>
            </tr>

            <tr></tr>
        </table>
        </fieldset>
    </div>

    <div class="clr"></div>

    <input type="hidden" name="option" value="com_ps_basico" />
    <input type="hidden" name="id" value="<?php echo $this->item->id; ?>" />
    <input type="hidden" name="view" value="adwords" />
    <input type="hidden" name="controller" value="adwords" />
    <input type="hidden" name="task" value="save" />
</form>
