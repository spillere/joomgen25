<?php
/**
 * Adwords HTML List Template
 *
 * PHP versions 5
 *
 * @category  Template
 * @package   Basico
 * @author    Rodrigo Spillere - JetWorks <rodrigo@jetworks.com.br>
 * @copyright 2010 JetWorks. All rights reserved.
 * @license   GNU General Public License
 * @link      http://jetworks.com.br
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');
jimport('joomla.filter.filteroutput');
?>

<table class="adminform"><tr><td>
<div id="adwords">
    <form action="index.php" method="post" name="adminForm">
    <div id="editcell">
        <table class="adminlist">
        <thead>
            <tr>
                <th width="5"><?php echo JText::_('ID'); ?></th>
                <th width="20"><input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($this->items); ?>);" /></th>
                  <th><?php echo JText::_('Plano'); ?></th>
                  <th><?php echo JText::_('Onde Anunciar'); ?></th>
                  <th><?php echo JText::_('Palavras Chaves'); ?></th>
                  <th><?php echo JText::_('Dados Google'); ?></th>
                  <th><?php echo JText::_('Produtos Servicos'); ?></th>
                  <th><?php echo JText::_('Vantagens'); ?></th>
                  <th><?php echo JText::_('Obs Google'); ?></th>

            </tr>
        </thead>
        <?php
            $k = 0;
            $i = 0;
            foreach($this->items as $row)
            {
                JFilterOutput::objectHTMLSafe($row);
                $checked = JHTML::_('grid.id', $i, $row->id);
                $link = JRoute::_('index.php?option=com_ps_basico&view=adwords&task=edit&cid[]='. $row->id, false);
        ?>
                <tr class="<?php echo "row$k"; ?>">
                    <td><?php echo $row->id; ?></td>
                    <td><?php echo $checked; ?></td>
                       <td><?php echo "<a href='$link'>".$row->plano."</a>"; ?></td>
                       <td><?php echo "<a href='$link'>".$row->onde_anunciar."</a>"; ?></td>
                       <td><?php echo "<a href='$link'>".$row->palavras_chaves."</a>"; ?></td>
                       <td><?php echo "<a href='$link'>".$row->dados_google."</a>"; ?></td>
                       <td><?php echo "<a href='$link'>".$row->produtos_servicos."</a>"; ?></td>
                       <td><?php echo "<a href='$link'>".$row->vantagens."</a>"; ?></td>
                       <td><?php echo "<a href='$link'>".$row->obs_google."</a>"; ?></td>

                </tr>
        <?php
                $k = 1 - $k;
                $i = $i + 1;
            }
        ?>
        </table>
    </div>
    <input type="hidden" name="option" value="com_ps_basico" />
    <input type="hidden" name="task" value="" />
    <input type="hidden" name="boxchecked" value="0" />
    <input type="hidden" name="view" value="adwords" />
    <input type="hidden" name="controller" value="adwords" />
</div>
</td></tr></table>
