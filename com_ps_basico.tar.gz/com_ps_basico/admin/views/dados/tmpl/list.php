<?php
/**
 * Dados HTML List Template
 *
 * PHP versions 5
 *
 * @category  Template
 * @package   Basico
 * @author    Rodrigo Spillere - JetWorks <rodrigo@jetworks.com.br>
 * @copyright 2010 JetWorks. All rights reserved.
 * @license   GNU General Public License
 * @link      http://jetworks.com.br
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');
jimport('joomla.filter.filteroutput');
?>

<table class="adminform"><tr><td>
<div id="dados">
    <form action="index.php" method="post" name="adminForm">
    <div id="editcell">
        <table class="adminlist">
        <thead>
            <tr>
                <th width="5"><?php echo JText::_('ID'); ?></th>
                <th width="20"><input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($this->items); ?>);" /></th>
                  <th><?php echo JText::_('Nome'); ?></th>
                  <th><?php echo JText::_('Cep'); ?></th>
                  <th><?php echo JText::_('Endereco'); ?></th>
                  <th><?php echo JText::_('Cidade'); ?></th>
                  <th><?php echo JText::_('Uf'); ?></th>
                  <th><?php echo JText::_('Complemento'); ?></th>
                  <th><?php echo JText::_('Cnpj'); ?></th>
                  <th><?php echo JText::_('Telefones'); ?></th>
                  <th><?php echo JText::_('Email'); ?></th>
                  <th><?php echo JText::_('Email Cobranca'); ?></th>
                  <th><?php echo JText::_('Dominio'); ?></th>
                  <th><?php echo JText::_('Nome Do Site'); ?></th>
                  <th><?php echo JText::_('Logo'); ?></th>

            </tr>
        </thead>
        <?php
            $k = 0;
            $i = 0;
            foreach($this->items as $row)
            {
                JFilterOutput::objectHTMLSafe($row);
                $checked = JHTML::_('grid.id', $i, $row->id);
                $link = JRoute::_('index.php?option=com_ps_basico&view=dados&task=edit&cid[]='. $row->id, false);
        ?>
                <tr class="<?php echo "row$k"; ?>">
                    <td><?php echo $row->id; ?></td>
                    <td><?php echo $checked; ?></td>
                       <td><?php echo "<a href='$link'>".$row->nome."</a>"; ?></td>
                       <td><?php echo "<a href='$link'>".$row->cep."</a>"; ?></td>
                       <td><?php echo "<a href='$link'>".$row->endereco."</a>"; ?></td>
                       <td><?php echo "<a href='$link'>".$row->cidade."</a>"; ?></td>
                       <td><?php echo "<a href='$link'>".$row->uf."</a>"; ?></td>
                       <td><?php echo "<a href='$link'>".$row->complemento."</a>"; ?></td>
                       <td><?php echo "<a href='$link'>".$row->cnpj."</a>"; ?></td>
                       <td><?php echo "<a href='$link'>".$row->telefones."</a>"; ?></td>
                       <td><?php echo "<a href='$link'>".$row->email."</a>"; ?></td>
                       <td><?php echo "<a href='$link'>".$row->email_cobranca."</a>"; ?></td>
                       <td><?php echo "<a href='$link'>".$row->dominio."</a>"; ?></td>
                       <td><?php echo "<a href='$link'>".$row->nome_do_site."</a>"; ?></td>
                       <td><?php echo "<a href='$link'>".$row->logo."</a>"; ?></td>

                </tr>
        <?php
                $k = 1 - $k;
                $i = $i + 1;
            }
        ?>
        </table>
    </div>
    <input type="hidden" name="option" value="com_ps_basico" />
    <input type="hidden" name="task" value="" />
    <input type="hidden" name="boxchecked" value="0" />
    <input type="hidden" name="view" value="dados" />
    <input type="hidden" name="controller" value="dados" />
</div>
</td></tr></table>
