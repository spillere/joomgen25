<?php
/**
 * Templates HTML View Class
 *
 * PHP versions 5
 *
 * @category  View
 * @package   Basico
 * @author    Rodrigo Spillere - JetWorks <rodrigo@jetworks.com.br>
 * @copyright 2010 JetWorks. All rights reserved.
 * @license   GNU General Public License
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');

/**
 * HTML View class for the Basico component
 *
 * @category View
 * @package  Basico
 * @author   Rodrigo Spillere - JetWorks <rodrigo@jetworks.com.br>
 * @license  GNU General Public License
 * @link     http://jetworks.com.br
 * @since    1.0
 */
class BasicoViewTemplates extends JView
{
    /**
     * Display the view
     *
     * @param string $tpl Template
     *
     * @return void
     * @access public
     * @since  1.0
     */
    function display($tpl = null)
    {
        // Set toolbar items
        JToolBarHelper::title(JText::_('Manage Templates'), 'generic.png');

        // Handle different data for different layouts
        $layout = JRequest::getVar('layout');
        if($layout == "list") {
            JToolBarHelper::deleteList();
            JToolBarHelper::editListX();
            JToolBarHelper::addNewX();
            $this->assignRef('items', $this->get('Items'));
        } else {
            $this->assignRef('item', $this->get('Item'));
            JToolBarHelper::save();
            JToolBarHelper::cancel();
        }

        parent::display($tpl);
    }
}
