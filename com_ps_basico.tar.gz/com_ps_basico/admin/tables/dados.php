<?php
/**
 * Dados Table Class
 *
 * PHP versions 5
 *
 * @category  Table_Class
 * @package   Basico
 * @author    Rodrigo Spillere - JetWorks <rodrigo@jetworks.com.br>
 * @copyright 2010 JetWorks. All rights reserved.
 * @license   GNU General Public License
 * @version   1.0.0
 * @link      http://jetworks.com.br
 */

// Check to ensure this file is within the rest of the framework
defined('_JEXEC') or die('Restricted access');

/**
 * Dados Table Class
 *
 * @category  Table_Class
 * @package   Basico
 * @author    Rodrigo Spillere - JetWorks <rodrigo@jetworks.com.br>
 * @copyright 2010 JetWorks. All rights reserved.
 * @license   GNU General Public License
 * @version   1.0.0
 */
class JTableDados extends JTable
{
    /**
     * @var int Primary key
     */
    var $id = null;
    
    /**
     * @var string Nome
     */
    var $nome = '';

    /**
     * @var string Cep
     */
    var $cep = '';

    /**
     * @var string Endereco
     */
    var $endereco = '';

    /**
     * @var string Cidade
     */
    var $cidade = '';

    /**
     * @var string Uf
     */
    var $uf = '';

    /**
     * @var string Complemento
     */
    var $complemento = '';

    /**
     * @var string Cnpj
     */
    var $cnpj = '';

    /**
     * @var string Telefones
     */
    var $telefones = '';

    /**
     * @var string Email
     */
    var $email = '';

    /**
     * @var string Email Cobranca
     */
    var $email_cobranca = '';

    /**
     * @var string Dominio
     */
    var $dominio = '';

    /**
     * @var string Nome Do Site
     */
    var $nome_do_site = '';

    /**
     * @var string Logo
     */
    var $logo = '';

    /**
     * Constructor
     *
     * @param object &$db A database connector object
     *
     * @return void
     * @access public
     * @since  1.0
     */
    public function __construct(&$db)
    {
        parent::__construct('#__ps_basico_dados', 'id', $db);
    }

    /**
     * Overloaded check function
     *
     * @return boolean
     * @access public
     * @since  1.0
     * @see    JTable::check
     */
    public function check()
    {
        // check required fields
        $required_fields = array('nome' => 'Nome', 'cep' => 'Cep', 'endereco' => 'Endereco', 'cidade' => 'Cidade', 'uf' => 'Uf', 'complemento' => 'Complemento', 'cnpj' => 'Cnpj', 'telefones' => 'Telefones', 'email' => 'Email', 'email_cobranca' => 'Email Cobranca', 'dominio' => 'Dominio', 'nome_do_site' => 'Nome Do Site', 'logo' => 'Logo');
        foreach($required_fields as $field => $description) {
            if($this->get($field) == null) {
                $this->setError(JText::_($description.' is required.'));
                return false;
            }
        }

        return true;
    }
}
?>
