<?php
/**
 * Adwords Table Class
 *
 * PHP versions 5
 *
 * @category  Table_Class
 * @package   Basico
 * @author    Rodrigo Spillere - JetWorks <rodrigo@jetworks.com.br>
 * @copyright 2010 JetWorks. All rights reserved.
 * @license   GNU General Public License
 * @version   1.0.0
 * @link      http://jetworks.com.br
 */

// Check to ensure this file is within the rest of the framework
defined('_JEXEC') or die('Restricted access');

/**
 * Adwords Table Class
 *
 * @category  Table_Class
 * @package   Basico
 * @author    Rodrigo Spillere - JetWorks <rodrigo@jetworks.com.br>
 * @copyright 2010 JetWorks. All rights reserved.
 * @license   GNU General Public License
 * @version   1.0.0
 */
class JTableAdwords extends JTable
{
    /**
     * @var int Primary key
     */
    var $id = null;
    
    /**
     * @var string Plano
     */
    var $plano = '';

    /**
     * @var string Onde Anunciar
     */
    var $onde_anunciar = '';

    /**
     * @var string Palavras Chaves
     */
    var $palavras_chaves = '';

    /**
     * @var string Dados Google
     */
    var $dados_google = '';

    /**
     * @var string Produtos Servicos
     */
    var $produtos_servicos = '';

    /**
     * @var string Vantagens
     */
    var $vantagens = '';

    /**
     * @var string Obs Google
     */
    var $obs_google = '';

    /**
     * Constructor
     *
     * @param object &$db A database connector object
     *
     * @return void
     * @access public
     * @since  1.0
     */
    public function __construct(&$db)
    {
        parent::__construct('#__ps_basico_adwords', 'id', $db);
    }

    /**
     * Overloaded check function
     *
     * @return boolean
     * @access public
     * @since  1.0
     * @see    JTable::check
     */
    public function check()
    {
        // check required fields
        $required_fields = array('plano' => 'Plano', 'onde_anunciar' => 'Onde Anunciar', 'palavras_chaves' => 'Palavras Chaves', 'dados_google' => 'Dados Google', 'produtos_servicos' => 'Produtos Servicos', 'vantagens' => 'Vantagens', 'obs_google' => 'Obs Google');
        foreach($required_fields as $field => $description) {
            if($this->get($field) == null) {
                $this->setError(JText::_($description.' is required.'));
                return false;
            }
        }

        return true;
    }
}
?>
